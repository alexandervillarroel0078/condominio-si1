<?php

namespace App\Http\Controllers;

use App\Http\Requests\LoginRequest;
use Illuminate\Support\Facades\Auth;
use App\Traits\BitacoraTrait;

class LoginController extends Controller
{
    use BitacoraTrait;

    public function index(){
        // si hay un usuario autenticado
        if(Auth::check()){
            return redirect()->route('panel');
        }
        // si no hay un usuario autenticado
        return view('auth.login');
    }

    public function login(LoginRequest $request){
        // validando las credenciales
        if(!Auth::validate($request->only('email','password'))){
            return redirect()->to('login')->withErrors('Credenciales incorrectas');
        }

        // creando una sesión...
        $user = Auth::getProvider()->retrieveByCredentials($request->only('email','password'));
        Auth::login($user);

        // Registrar acción en la bitácora
        $this->registrarEnBitacora('Usuario inició sesión', $user->id);

        return redirect()->route('panel');
    }
}
