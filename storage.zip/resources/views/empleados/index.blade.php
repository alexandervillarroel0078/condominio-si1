@extends('plantilla')

@section('title', 'Empleados')

@push('css')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@endpush

@section('content')

    @if (session('success'))
        <script>
            let message = "{{ session('success') }}"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: message
            });
        </script>
    @endif

    <div class="container-fluid px-4">
        <h1 class="mt-4">Empleados(personal del salon)</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="{{ route('panel') }}"> Inicio </a></li>
            <li class="breadcrumb-item active">Empleados</li>
        </ol>
        <div class="mb-4">
            <a href="{{ route('empleados.create') }}"><button type="button" class="btn btn-primary btn-sm">Nuevo
                    empleado(personal del salon)</button></a>
        </div>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Tabla Empleados(personal del salon)
            </div>
            <div class="card-body">
                <table id="datatablesSimple" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Ci</th>
                            <th>Teléfono</th>
                            <th>Dirección</th>
                            <th>T. personal </th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($empleados as $empleado)
                            <tr>
                                <td>
                                    {{ $empleado->nombre }}
                                </td>
                                <td>
                                    {{ $empleado->ci }}
                                </td>
                                <td>
                                    {{ $empleado->telefono }}
                                </td>
                                <td>
                                    {{ $empleado->direccion }}
                                </td>
                                <td>
                                    {{ $empleado->tipo_empleado }}
                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <form action="{{ route('empleados.edit', ['empleado' => $empleado]) }}"
                                            method="GET">
                                            <button type="submit" class="btn btn-primary btn-sm">Editar</button>
                                        </form>
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#confimarModal-{{ $empleado->id }}">Eliminar</button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Modal -->
                            <div class="modal fade" id="confimarModal-{{ $empleado->id }}" data-bs-backdrop="static"
                                data-bs-keyboard="false" tabindex="-1" aria-labelledby="confimarModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="confimarModalLabel">Eliminar empleado</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            ¿ Desea eliminar al empleado: {{ $empleado->nombre }}?
                                        </div>
                                        <div class="modal-footer">
                                            <form action="{{ route('empleados.destroy', ['empleado' => $empleado->id]) }}"
                                                method="POST">
                                                @csrf
                                                @method('delete')
                                                <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                            </form>
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="{{ asset('js/datatables-simple-demo.js') }}"></script>
@endpush
