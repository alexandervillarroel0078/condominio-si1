<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notacompras', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('proveedore_id')->constrained('proveedores')->restrictOnDelete();
            $table->foreignId('almacene_id')->constrained('almacenes')->restrictOnDelete();
            $table->dateTime('fecha');
            $table->dateTime('fecha_recepcion');
            $table->decimal('total', 10, 3);
            $table->string('tipo_pago', 45);
            $table->string('descripcion', 150)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notacompras');
    }
};
