<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Empleado extends Model
{
    use HasFactory;

    public function user(){
        return $this->hasOne(User::class);
    }

    public function contratos(){
        return $this->hasMany(Contrato::class);
    }

    public function boletapagos(){
        return $this->hasMany(Boletapago::class);
    }

    public function anticipoempleados(){
        return $this->hasMany(Anticipoempleado::class);
    }

    protected $fillable = ['nombre', 'ci', 'telefono', 'direccion', 'tipo_empleado', 'fecha_alta'];
}
