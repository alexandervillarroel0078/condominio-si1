{{-- 📁 resources/views/servicios/create.blade.php --}}
@extends('plantilla')

@section('title', 'Nuevo servicio')

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">Nuevo servicio</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="{{ route('panel') }}">Inicio</a></li>
        <li class="breadcrumb-item"><a href="{{ route('servicios.index') }}">Servicios</a></li>
        <li class="breadcrumb-item active">Crear</li>
    </ol>

    <form action="{{ route('servicios.store') }}" method="POST">
        @csrf
        <div class="form-group mb-2">
            <label>Nombre del servicio</label>
            <input type="text" name="nombre" class="form-control" required value="{{ old('nombre') }}">
        </div>
        <div class="form-group mb-2">
            <label>Descripción (opcional)</label>
            <textarea name="descripcion" class="form-control">{{ old('descripcion') }}</textarea>
        </div>
        <div class="form-group mb-2">
            <label>Duración (minutos)</label>
            <input type="number" name="duracion_minutos" class="form-control" required min="5" value="{{ old('duracion_minutos') }}">
        </div>
        <div class="form-group mb-2">
            <label>Precio (Bs.)</label>
            <input type="number" name="precio" class="form-control" step="0.01" required value="{{ old('precio') }}">
        </div>
        <div class="form-group mb-3">
            <label>Categoría (opcional)</label>
            <input type="text" name="categoria" class="form-control" value="{{ old('categoria') }}">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-sm">Guardar</button>
            <a href="{{ route('servicios.index') }}" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
    </form>
</div>
@endsection
