<?php

namespace Database\Seeders;

use App\Models\Cliente;
use App\Models\Clasificadore;
use App\Models\Empleado;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $this->call([
            RolesSeeder::class,
            ClasificadoresSeeder::class,
            ClientesSeeder::class,
            EmpleadosSeeder::class,
            PermissionSeeder::class,
            UsuariosSeeder::class
        ]);        
        
       
    }
}
