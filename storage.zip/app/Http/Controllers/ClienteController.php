<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreClienteRequest;
use App\Http\Requests\StoreTelefonoRequest;
use App\Http\Requests\UpdateClienteRequest;
use App\Models\Clasificadore;
use App\Models\Cliente;
use App\Models\Telefono;
use App\Traits\BitacoraTrait;
use Exception;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Http\Request;

class ClienteController extends Controller
{
    use BitacoraTrait;

    public function index(Request $request)
    {
        $nombre = $request->nombre;
        $estado = $request->estado;
        $tipo_cliente = $request->tipo_cliente;
        $tipo_clientes = Clasificadore::where('tipo', 'TIPO_CLIENTE')->get();

        $clientes = Cliente::filtrarPorNombre($request)
            ->filtrarPorTipo($request)
            ->filtrarPorEstado($request)
            ->get();

        return view('clientes.index', compact('clientes', 'tipo_clientes', 'nombre', 'estado', 'tipo_cliente'));
    }

    public function storeTelefono(StoreTelefonoRequest $request, string $id)
    {
        $cliente = Cliente::find($id);
        $telefono = new Telefono();
        $telefono->fill([
            'cliente_id' => $id,
            'numero' => $request->numero
        ]);
        $telefono->save();

        // Registrar acción en la bitácora
        $this->registrarEnBitacora('Teléfono registrado', $cliente->id);

        return redirect()->route('clientes.edit', compact('cliente'))->with('success', 'Teléfono registrado con éxito.');
    }

    public function deleteTelefono(string $id, string $telefono_id)
    {
        $cliente = Cliente::find($id);
        $telefono = Telefono::find($telefono_id);
        $telefono->delete();

        // Registrar acción en la bitácora
        $this->registrarEnBitacora('Teléfono eliminado', $cliente->id);

        return redirect()->route('clientes.edit', compact('cliente'))->with('success', 'Teléfono eliminado con éxito.');
    }

    public function create()
    {
        $tipo_clientes = Clasificadore::where('tipo', 'TIPO_CLIENTE')->get();
        return view('clientes.create', compact('tipo_clientes'));
    }

    public function pdfCliente(string $id)
    {
        $cliente = Cliente::find($id);
        $telefonos = Telefono::where('cliente_id', $cliente->id)->get();
        $pdf = PDF::loadView('clientes.pdfCliente', compact('cliente', 'telefonos'));
        return $pdf->stream();
    }

    public function pdfClientes(Request $request)
    {
        $nombre = $request->nombre;
        $estado = $request->estado;
        $tipo_cliente = $request->tipo_cliente;
        $tipo_clientes = Clasificadore::where('tipo', 'TIPO_CLIENTE')->get();

        $clientes = Cliente::filtrarPorNombre($request)
            ->filtrarPorTipo($request)
            ->filtrarPorEstado($request)
            ->get();
        $pdf = PDF::loadView('clientes.pdfListadoClientes', compact('clientes', 'nombre', 'estado', 'tipo_cliente'));
        return $pdf->stream();        
    }

    public function store(StoreClienteRequest $request)
    {
        $cliente = new Cliente();
        try {
            DB::beginTransaction();

            $cliente = Cliente::create([
                'nombre' => $request->nombre,
                'ci' => $request->ci,
                'nit' => $request->nit,
                'tipo_cliente' => $request->tipo_cliente,
                'email' => $request->email,
                'direccion' => $request->direccion
            ]);
            $telefono = new Telefono();
            $telefono->fill([
                'cliente_id' => $cliente->id,
                'numero' => $request->telefono
            ]);
            $telefono->save();

            DB::commit();

            // Registrar acción en la bitácora
            $this->registrarEnBitacora('Cliente registrado', $cliente->id);
        } catch (Exception $e) {
            DB::rollback();
        }
        
        return redirect()->route('clientes.index')->with('success', 'Cliente registrado con éxito.');
    }

    public function show()
    {
        //
    }

    public function edit(Cliente $cliente)
    {
        $tipo_clientes = Clasificadore::where('tipo', 'TIPO_CLIENTE')->get();
        $telefonos = Telefono::where('cliente_id', $cliente->id)->get();
        return view('clientes.edit', compact('cliente', 'tipo_clientes', 'telefonos'));
    }

    public function update(UpdateClienteRequest $request, Cliente $cliente)
    {
        Cliente::where('id', $cliente->id)->update($request->validated());

        // Registrar acción en la bitácora
        $this->registrarEnBitacora('Cliente actualizado', $cliente->id);

        return redirect()->route('clientes.index')->with('success', 'El cliente se ha actualizado');
    }

    public function destroy(string $id)
    {
        $cliente = Cliente::find($id);
        $valor = 1;
        if ($cliente->estado == 1) {
            $valor = 0;
        }
        Cliente::where('id', $id)->update([
            'estado' => $valor
        ]);

        // Registrar acción en la bitácora
        $this->registrarEnBitacora($valor == 0 ? 'Cliente dado de baja' : 'Cliente restaurado', $cliente->id);

        return redirect()->route('clientes.index')->with('success', $valor == 0 ? 'El cliente ha sido dado de baja' : 'El cliente ha sido restaurado');
    }
}
