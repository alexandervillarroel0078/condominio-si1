<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('listaprecioproducto_pedido', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pedido_id')->constrained('pedidos')->restrictOnDelete();
            $table->foreignId('listaprecioproducto_id')->constrained('listaprecioproductos')->restrictOnDelete();
            $table->unsignedInteger('cantidad');
            $table->decimal('precio_venta', 10, 3);
            $table->string('descripcion', 150);
            $table->decimal('subtotal', 10, 3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('listaprecioproducto_pedido');
    }
};
