{{-- 📁 resources/views/servicios/index.blade.php --}}
@extends('plantilla')

@section('title', 'Servicios')

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">Servicios ofrecidos</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="{{ route('panel') }}">Inicio</a></li>
        <li class="breadcrumb-item active">Servicios</li>
    </ol>

    <a href="{{ route('servicios.create') }}" class="btn btn-primary btn-sm mb-3">Nuevo servicio</a>

    @if (session('success'))
        <div class="alert alert-success small">{{ session('success') }}</div>
    @endif

    <div class="card mb-4">
        <div class="card-header">Listado de servicios</div>
        <div class="card-body">
            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Duración (min)</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($servicios as $servicio)
                        <tr>
                            <td>{{ $servicio->nombre }}</td>
                            <td>{{ $servicio->duracion_minutos }}</td>
                            <td>Bs. {{ number_format($servicio->precio, 2) }}</td>
                            <td>{{ $servicio->categoria ?? 'Sin categoría' }}</td>
                            <td>
                                <a href="{{ route('servicios.edit', $servicio->id) }}" class="btn btn-sm btn-warning">Editar</a>
                                <form action="{{ route('servicios.destroy', $servicio->id) }}" method="POST" style="display:inline-block;">
                                    @csrf @method('DELETE')
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar este servicio?')">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                    @if ($servicios->isEmpty())
                        <tr><td colspan="5">No hay servicios registrados.</td></tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
