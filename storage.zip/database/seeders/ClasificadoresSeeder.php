<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ClasificadoresSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $tipos = [
            // insertando tipo empleado
            [
                'descripcion' => 'Estilista',
                'tipo' => 'TIPO_EMPLEADO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'Manicurista',
                'tipo' => 'TIPO_EMPLEADO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'Barbero',
                'tipo' => 'TIPO_EMPLEADO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo rol usuario
            [
                'descripcion' => 'SUPER ADMINISTRADOR',
                'tipo' => 'ROL_USUARIO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'ADMINISTRADOR',
                'tipo' => 'ROL_USUARIO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'CONTABLE',
                'tipo' => 'ROL_USUARIO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'AGENTE COMERCIAL',
                'tipo' => 'ROL_USUARIO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo cliente
            [
                'descripcion' => 'PARTICULAR',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'EMPRESA',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'VIP',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'NUEVO',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'RECOMENDADO',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'FRECUENTE',
                'tipo' => 'TIPO_CLIENTE',
                'created_at' => now(),
                'updated_at' => now()
            ],
            
            // insertando tipo pago
            [
                'descripcion' => 'EFECTIVO',
                'tipo' => 'TIPO_PAGO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'TRANSFERENCIA',
                'tipo' => 'TIPO_PAGO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'TARJETA',
                'tipo' => 'TIPO_PAGO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'CHEQUE',
                'tipo' => 'TIPO_PAGO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo cobro
            [
                'descripcion' => 'EFECTIVO',
                'tipo' => 'TIPO_COBRO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'TRANSFERENCIA',
                'tipo' => 'TIPO_COBRO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'TARJETA',
                'tipo' => 'TIPO_COBRO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'CHEQUE',
                'tipo' => 'TIPO_COBRO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo sueldo
            [
                'descripcion' => 'SUELDO',
                'tipo' => 'TIPO_SUELDO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo anticipo
            [
                'descripcion' => 'ANTICIPO',
                'tipo' => 'TIPO_ANTICIPO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo prestamo
            [
                'descripcion' => 'PRESTAMO',
                'tipo' => 'TIPO_PRESTAMO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo bono
            [
                'descripcion' => 'BONO ANTIGUEDAD',
                'tipo' => 'TIPO_BONO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'BONO PRODUCCION',
                'tipo' => 'TIPO_BONO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'BONO DOMINICAL',
                'tipo' => 'TIPO_BONO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo descuento
            [
                'descripcion' => 'PDESCUENTO AFP',
                'tipo' => 'TIPO_DESCUENTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'DESCUENTO APORTE SOLIDARIO',
                'tipo' => 'TIPO_DESCUENTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'DESCUENTO RIESGO COMUN',
                'tipo' => 'TIPO_DESCUENTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo accion de la bitacora
            [
                'descripcion' => 'INGRESO',
                'tipo' => 'TIPO_ACCION',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'SALIDA',
                'tipo' => 'TIPO_ACCION',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'INSERTAR',
                'tipo' => 'TIPO_ACCION',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'BORRAR',
                'tipo' => 'TIPO_ACCION',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'MODIFICAR',
                'tipo' => 'TIPO_ACCION',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo motivo de la salida de producto
            [
                'descripcion' => 'VENTA',
                'tipo' => 'TIPO_MOTIVO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'DEFECTUOSO',
                'tipo' => 'TIPO_MOTIVO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo producto
            [
                'descripcion' => 'MADERA',
                'tipo' => 'TIPO_PRODUCTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'MELAMINICO',
                'tipo' => 'TIPO_PRODUCTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'SILLA',
                'tipo' => 'TIPO_PRODUCTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'MESA',
                'tipo' => 'TIPO_PRODUCTO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            // insertando tipo precio
            [
                'descripcion' => 'MINORISTA',
                'tipo' => 'TIPO_PRECIO',
                'created_at' => now(),
                'updated_at' => now()
            ],
            [
                'descripcion' => 'MAYORISTA',
                'tipo' => 'TIPO_PRECIO',
                'created_at' => now(),
                'updated_at' => now()
            ]
        ];
        DB::table('clasificadores')->insert($tipos);
    }
}
