<?php $__env->startSection('title', 'Crear pedido'); ?>

<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" />
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
        
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Solicitar servicio</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item "><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
            <li class="breadcrumb-item "><a href="<?php echo e(route('pedidos.index')); ?>">Solicitar servicio</a></li>
            <li class="breadcrumb-item active">Crear</li>
        </ol>
        <div class="from-orange-200">
            <form action="<?php echo e(route('pedidos.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="container-lg mt-2">
                    <div class="row gy-2">
                        <!------Pedido producto---->
                        <div class="col-xl-8">
                            <div class="text-white bg-secondary p-1 text-center">
                                Detalles del pedido
                            </div>
                            <div class="p-3 border border-3 border-secondary">
                                <div class="row">
                                    <!-----Producto---->
                        <!-- Servicio del catálogo -->
<div class="col-12 mb-4">
    <label for="servicio_id" class="form-label">Servicio:</label>
    <select name="servicio_id" id="servicio_id" class="form-select select2"
        data-placeholder="Seleccione un servicio">
        <option></option>
        <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($servicio->id); ?>">
                <?php echo e($servicio->nombre); ?> (<?php echo e($servicio->duracion_minutos); ?> min) - Bs. <?php echo e(number_format($servicio->precio, 2)); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</div>

                                </div>
                            </div>
                        </div>
                        <!-----Cabecera pedido---->
                        <div class="col-xl-4">
                            <div class="text-white bg-primary p-1 text-center">
                                Datos generales
                            </div>
                            <div class="p-3 border border-3 border-primary">
                                <div class="row">
                                    <!--Clientes-->
                                    <div class="col-12 mb-2">
                                        <label for="cliente_id" class="form-label">Cliente:</label>
                                        <select class="form-select" name="cliente_id" id="cliente_id"
                                            data-placeholder="Seleccione cliente">
                                            <option></option>
                                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($cliente->id); ?>"><?php echo e($cliente->nombre); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['cliente_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <small class="text-danger"><?php echo e('*' . $message); ?></small>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <!--Numero--->
                                    <div class="col-sm-6 mb-2">
                                        <label for="numero" class="form-label">Fecha entrega:</label>
                                        <input type="text" name="numero" id="numero"
                                            class="form-control border-success" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                    <!--Fecha entrega--->
                                    <div class="col-sm-6 mb-2">
                                        <label for="fecha" class="form-label">Fecha entrega:</label>
                                        <input type="text" name="fecha_entrega" id="fecha_entrega"
                                            class="form-control border-success" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                    <!--Fecha--->
                                    <div class="col-sm-6 mb-2">
                                        <label for="fecha" class="form-label">Fecha:</label>
                                        <input readonly type="date" name="fecha" id="fecha"
                                            class="form-control border-success" value="<?php echo date('Y-m-d'); ?>">
                                    </div>
        
        
                                    <!--Botones--->
                                    <div class="col-12 mt-4 text-center">
                                        <button type="submit" class="btn btn-primary" id="guardar">Crear pedido</button>
                                    </div>
        
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.full.min.js"></script>
    <script>
        $('#cliente_id').select2({
            theme: "bootstrap-5",
            width: $(this).data('width') ? $(this).data('width') : $(this).hasClass('w-100') ? '100%' : 'style',
            placeholder: $(this).data('placeholder'),
        });
        $('#servicio_id').select2({
    theme: "bootstrap-5",
    width: '100%',
    placeholder: "Seleccione un servicio",
});

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/pedidos/create.blade.php ENDPATH**/ ?>