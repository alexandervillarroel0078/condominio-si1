<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('detalleboletapagos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('boletapago_id')->constrained('boletapagos')->restrictOnDelete();
            $table->string('descripcion', 150);
            $table->string('tipo', 45);
            $table->decimal('monto', 10,3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('detalleboletapagos');
    }
};
