@extends('plantilla')

@section('title', 'Editar cliente')

@push('css')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@endpush

@section('content')
@if (session('success'))
        <script>
            let message = "{{ session('success') }}"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: message
            });
        </script>
    @endif

    <div class="container-fluid px-4">
        <h1 class="mt-4">Editar cliente</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item "><a href="{{ route('panel') }}"> Inicio</a></li>
            <li class="breadcrumb-item "><a href="{{ route('clientes.index') }}">Clientes</a></li>
            <li class="breadcrumb-item active">Editar</li>
        </ol>
        <div class="row">
            <div class="col-sm-8">
                <form action="{{ route('clientes.update', ['cliente' => $cliente]) }}" method="POST">
                    @csrf
                    @method('PATCH')
                    <div class="row">
                        <div class="col-sm-6 mb-2">
                            <label for="tipo_cliente">Tipo cliente</label>
                            <select class="form-control" name="tipo_cliente" id="tipo_cliente" onchange="ShowSelected();">
                                <option value="">Seleccione Tipo Cliente</option>
                                @foreach ($tipo_clientes as $tipo_cliente)
                                    <option value="{{ $tipo_cliente->descripcion }}"
                                        {{ $cliente->tipo_cliente == $tipo_cliente->descripcion ? 'selected' : '' }}>
                                        {{ $tipo_cliente->descripcion }} </option>
                                @endforeach
                            </select>
                            @error('tipo_cliente')
                                <small class="text-danger"> {{ '*' . $message }} </small>
                            @enderror
                        </div>

                        <div class="col-sm-6 mb-2" id="grupoCI"
                            style="display:{{ $cliente->tipo_cliente == 'PARTICULAR' ? '' : 'none' }}">
                            <label for="ci">Nro CI</label>
                            <input type="number" class="form-control" name="ci" id="ci"
                                placeholder="introduzca CI" value="{{ old('ci', $cliente->ci) }}">
                            @error('ci')
                                <small class="text-danger"> {{ '*' . $message }} </small>
                            @enderror
                        </div>

                        <div class="col-sm-6 mb-2" id="grupoNIT"
                            style="display:{{ $cliente->tipo_cliente == 'EMPRESA' ? '' : 'none' }}">
                            <label for="nit">Nro NIT</label>
                            <input type="number" class="form-control" name="nit" id="nit"
                                placeholder="introduzca NIT" value="{{ old('nit', $cliente->nit) }}">
                            @error('nit')
                                <small class="text-danger"> {{ '*' . $message }} </small>
                            @enderror
                        </div>
                    </div>

                    <div class="form-group mb-2">
                        <label for="nombre">Nombre completo</label>
                        <input type="text" class="form-control" name="nombre" id="nombre"
                            placeholder="introduzca nombre completo" value="{{ old('nombre', $cliente->nombre) }}">
                        @error('nombre')
                            <small class="text-danger"> {{ '*' . $message }} </small>
                        @enderror
                    </div>
                    <div class="form-group mb-2">
                        <label for="email">Correo electrónico</label>
                        <input type="email" class="form-control" name="email" id="email"
                            placeholder="nombre@ejemplo.com" value="{{ old('email', $cliente->email) }}">
                        @error('email')
                            <small class="text-danger"> {{ '*' . $message }} </small>
                        @enderror
                    </div>
                    <div class="form-group mb-2">
                        <label for="direccion">Dirección</label>
                        <input type="text" class="form-control" name="direccion" id="direccion"
                            placeholder="ingrese una dirección" value="{{ old('direccion', $cliente->direccion) }}">
                        @error('direccion')
                            <small class="text-danger"> {{ '*' . $message }} </small>
                        @enderror
                    </div>
                    <div class="col-12 text-center">
                        <button type="submit" class="btn btn-primary btn-sm"> Actualizar </button>
                        <button type="reset" class="btn btn-secondary btn-sm"> Restaurar datos </button>
                        <a href="{{ route('clientes.index') }}"><button type="button" class="btn btn-success btn-sm"> <i
                                    class="fa-solid fa-arrow-left"></i> Atras </button></a>
                    </div>
                </form>
            </div>
            <div class="col-sm-4">
                <h5>Telefono(s)</h5>
                <div class="card-body">
                    <table id="datatablesSimple" class="table table-striped">
                        <thead>
                            <tr>
                                <th>Número</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($telefonos as $telefono)
                                <tr>
                                    <td>
                                        {{ $telefono->numero }}
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <span class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                                data-bs-target="#eliminarTelefonoModal-{{ $telefono->id }}">
                                                <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="Eliminar teléfono" id="eliminar">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            </span>
                                        </div>
                                    </td>
                                </tr>
                                <!-- Modal eliminar telefono -->
                                <div class="modal fade" id="eliminarTelefonoModal-{{ $telefono->id }}" data-bs-backdrop="static"
                                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="confimarModalLabel"
                                    aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="confimarModalLabel">Eliminar teléfono</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                ¿ Desea eliminar el teléfono: {{ $telefono->numero }} ?
                                            </div>
                                            <div class="modal-footer">
                                                <form
                                                    action="{{ route('clientes.deltelefonos', ['cliente' => $cliente->id, 'telefono' => $telefono->id]) }}"
                                                    method="POST">
                                                    @csrf
                                                    <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                                </form>
                                                <button type="button" class="btn btn-secondary btn-sm"
                                                    data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="form-group" style="text-align:right">
                    <button data-bs-toggle="modal" data-bs-target="#adicionarTelefonoModal-{{ $cliente->id }}"
                        class="btn btn-primary btn-sm"> Añadir teléfono </button>
                </div>
                <!-- Modal adicionar teléfono -->
                <div class="modal fade" id="adicionarTelefonoModal-{{ $cliente->id }}" data-bs-backdrop="static"
                    data-bs-keyboard="false" tabindex="-1" aria-labelledby="confimarModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <form method="POST" action="{{ route('clientes.addtelefonos', ['cliente' => $cliente->id]) }}">
                                @csrf
                                <div class="modal-header">
                                    <h5 class="modal-title" id="confimarModalLabel">Adicionar teléfono</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <div class="form-group mb-2">
                                        <label for="numero">Teléfono</label>
                                        <input type="text" class="form-control" name="numero" id="numero"
                                            placeholder="introduzca número de teléfono" value="{{ old('numero') }}">
                                    </div>

                                </div>
                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                    <button type="button" class="btn btn-secondary btn-sm"
                                        data-bs-dismiss="modal">Cancelar</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        function ShowSelected() {
    var seleccion = $("#tipo_cliente option:selected").val();

    if (seleccion === 'PARTICULAR' || seleccion === 'VIP' || seleccion === 'NUEVO' || seleccion === 'FRECUENTE' || seleccion === 'RECOMENDADO') {
        $("#grupoCI").show();
        $("#grupoNIT").hide();
    } else if (seleccion === 'EMPRESA') {
        $("#grupoCI").hide();
        $("#grupoNIT").show();
    }
}

        $(function() {
            $('[data-bs-toggle="tooltip"]').tooltip();
        });
    </script>
@endpush
