@extends('plantilla')

@section('title', 'Crear cliente')

@push('css')
    <style type="text/css">
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }


        input[type=date]::-webkit-inner-spin-button,
        input[type=date]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=date] {
            -moz-appearance: textfield;
        }
    </style>
@endpush

@section('content')
    <div class="container-fluid px-4">
        <h1 class="mt-4">Crear cliente</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item "><a href="{{ route('panel') }}">Inicio</a></li>
            <li class="breadcrumb-item "><a href="{{ route('clientes.index') }}">Clientes</a></li>
            <li class="breadcrumb-item active">Crear</li>
        </ol>
        <div class="from-orange-200">
            <form action="{{ route('clientes.store') }}" method="POST">
                @csrf
                <div class="row">
                    <div class="col-sm-6 mb-2">
                        <label for="tipo_cliente">Tipo cliente</label>
                        <select class="form-control" name="tipo_cliente" id="tipo_cliente" onchange="ShowSelected();">
                            <option value="">--Seleccione Tipo Cliente--</option>
                            @foreach ($tipo_clientes as $tipo_cliente)
                                <option value="{{ $tipo_cliente->descripcion }}"
                                    {{ old('tipo_cliente') == $tipo_cliente->descripcion ? 'selected' : '' }}>
                                    {{ $tipo_cliente->descripcion }} </option>
                            @endforeach
                        </select>
                        @error('tipo_cliente')
                            <small class="text-danger">{{ '*' . $message }}</small>
                        @enderror
                    </div>

                    <div class="col-sm-6 mb-2" id="grupoCI">
                        <label for="ci">Nro CI</label>
                        <input type="number" class="form-control" name="ci" id="ci" placeholder="introduzca CI"
                            value="{{ old('ci') }}" width="100">
                        @error('ci')
                            <small class="text-danger"> {{ '*' . $message }} </small>
                        @enderror
                    </div>
                    <div class="col-sm-6 mb-2" id="grupoNIT">
                        <label for="nit">Nro NIT</label>
                        <input type="number" class="form-control" name="nit" id="nit"
                            placeholder="introduzca NIT" value="{{ old('nit') }}" width="120">
                        @error('nit')
                            <small class="text-danger"> {{ '*' . $message }} </small>
                        @enderror
                    </div>

                </div>
                <div class="form-group mb-2">
                    <label for="nombre">Nombre completo</label>
                    <input type="text" class="form-control" name="nombre" id="nombre"
                        placeholder="introduzca nombre completo" value="{{ old('nombre') }}">
                    @error('nombre')
                        <small class="text-danger"> {{ '*' . $message }} </small>
                    @enderror
                </div>
                <div class="form-group mb-2">
                    <label for="email">Correo electrónico</label>
                    <input type="email" class="form-control" name="email" id="email"
                        placeholder="nombre@ejemplo.com" value="{{ old('email') }}">
                    @error('email')
                        <small class="text-danger"> {{ '*' . $message }} </small>
                    @enderror
                </div>
                <div class="form-group mb-2">
                    <label for="direccion">Dirección</label>
                    <input type="text" class="form-control" name="direccion" id="direccion"
                        placeholder="ingrese una dirección" value="{{ old('direccion') }}">
                    @error('direccion')
                        <small class="text-danger"> {{ '*' . $message }} </small>
                    @enderror
                </div>
                <div class="form-group mb-2">
                    <label for="telefono">Teléfono</label>
                    <input type="text" class="form-control" name="telefono" id="telefono"
                        placeholder="ingrese número de telefono" value="{{ old('telefono') }}">
                    @error('telefono')
                        <small class="text-danger"> {{ '*' . $message }} </small>
                    @enderror
                </div>
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary btn-sm"> Guardar </button>
                </div>
            </form>
        </div>
    </div>
@endsection

@push('js')
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        function ShowSelected() {
    var seleccion = $("#tipo_cliente option:selected").val();

    if (seleccion === 'PARTICULAR' || seleccion === 'VIP' || seleccion === 'NUEVO' || seleccion === 'FRECUENTE' || seleccion === 'RECOMENDADO') {
        $("#grupoCI").show();
        $("#grupoNIT").hide();
    } else if (seleccion === 'EMPRESA') {
        $("#grupoCI").hide();
        $("#grupoNIT").show();
    }
}

    </script>
@endpush
