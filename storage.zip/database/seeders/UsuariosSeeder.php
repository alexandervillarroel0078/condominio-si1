<?php

namespace Database\Seeders;
use App\Models\User;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UsuariosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
       // id	empleado_id	role_id	name	email	activo	email_verified_at	
       // password	remember_token	created_at	updated_at	
        $passw = Hash::make('12345678');
        $usuario = User::create ([
            'empleado_id' => 1,
            'name' => 'remberto',
            'email' => 'remberto@gmail.com',
            'activo' => 1,
            'email_verified_at' => now(),
            'password' => $passw,
            'remember_token' => null,
            'created_at' => now(),
            'updated_at' => now()
        ]);
        //Usuario administrador
        $rol = Role::create(['name' => 'administrador']);
        $permisos = Permission::pluck('id','id')->all();
        $rol->syncPermissions($permisos);
        //$user = User::find(1);
        $usuario->assignRole('administrador');

       // DB::table('users')->insert($usuario);
    }
}
