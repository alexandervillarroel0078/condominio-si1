@extends('plantillaPDF')

@section('title', 'Imprimir cliente')

@push('css')
    <style>
        label.etiqueta-negrita {
            font-weight: bold;
            margin-bottom: 4pt;
        }
    </style>
@endpush

@section('content')
    <div class="container-fluid px-4">
        <h1 class="mt-1 mb-4">INFORMACIÓN CLIENTE</h1>
        <table>
            <tr>
                <td><label class="etiqueta-negrita">Tipo cliente : </label></td>
                <td>{{ $cliente->tipo_cliente }}</td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">Fecha alta : </label></td>
                <td><?php
                $date = new DateTime($cliente->fecha_alta);
                echo $date->format('d-m-Y');
                ?>
                </td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">Nombre completo : </label></td>
                <td>{{ $cliente->nombre }}</td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">{{ $cliente->tipo_cliente == 'PARTICULAR' ? 'CI' : 'NIT' }} : </label>
                </td>
                <td>{{ $cliente->tipo_cliente == 'PARTICULAR' ? $cliente->ci : $cliente->nit }} </td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">Correo electrónico : </label></td>
                <td>{{ $cliente->email }}</td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">Dirección : </label></td>
                <td>{{ $cliente->direccion }}</td>
            </tr>
            <tr>
                <td><label class="etiqueta-negrita">Teléfono(s) : </label></td>
                <td>
                    <?php 
                        $strTelefonos = '';
                        foreach ($telefonos as $telefono){
                            $strTelefonos = $strTelefonos . $telefono->numero . ' - ';
                        }
                        if (($strTelefonos) != '')
                            $strTelefonos = substr($strTelefonos, 0, -3);
                        echo($strTelefonos);
                    ?>                    
                </td>
            </tr>
        </table>
        <div class="form-group mt-5" style="text-align:right">
            <label class="">Fecha emisión : <?php            
                echo(date('d-m-Y, H:m:s'));
            ?></label> 
        </div>        
    </div>
@endsection

@push('js')
@endpush
