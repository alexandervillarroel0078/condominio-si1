<div id="layoutSidenav_nav">
    <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
        <div class="sb-sidenav-menu">
            <div class="nav">
                <div class="sb-sidenav-menu-heading">Inicio</div>
                <a class="nav-link" href="{{ route('panel') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                    Inicio
                </a>

                <div class="sb-sidenav-menu-heading">Modulos</div>
                <a class="nav-link" href="{{ route('users.index') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-users"></i></div>
                    Usuarios
                </a>
                <a class="nav-link" href="{{ route('empleados.index') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Empleados (personal)
                </a>
                <a class="nav-link" href="#" hidden>
                    <div class="sb-nav-link-icon"><i class="fas fa-chart-area"></i></div>
                    Planillas
                </a>
                <a class="nav-link" href="{{ route('servicios.index') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-scissors"></i></div>
                    Servicios
                </a>
                <!--   -->
                <!-- Ítem independiente: Clientes -->
                <a class="nav-link" href="{{ route('clientes.index') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                    Clientes
                </a>

                <!-- Ítem independiente: Pedidos -->
                <a class="nav-link" href="{{ route('pedidos.index') }}">
                    <div class="sb-nav-link-icon"><i class="fas fa-box"></i></div>
                    Pedidos (servicios)
                </a>

                <a class="nav-link collapsed" href="#" data-bs-toggle="collapse" data-bs-target="#collapseProveedores" aria-expanded="false" aria-controls="collapseProveedores" hidden>
                    <div class="sb-nav-link-icon"><i class="fas fa-columns"></i></div>
                    Proveedores
                    <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                </a>
                <div class="collapse" id="collapseProveedores" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                    <nav class="sb-sidenav-menu-nested nav">
                        <a class="nav-link" href="#">Proveedores</a>
                        <a class="nav-link" href="#">Compras</a>
                    </nav>
                </div>

                <a class="nav-link" href="{{ route('roles.index') }}">
                    <div class="sb-nav-link-icon"><i class="fa-solid fa-person-circle-plus"></i></div>
                    Roles
                </a>

                <a class="nav-link" href="{{ route('logout') }}">
                    <div class="sb-nav-link-icon"><i class="fa fa-sign-out" aria-hidden="true"></i></div>
                    Salir
                </a>
            </div>
        </div>
        <!--       
        <div class="sb-sidenav-footer">
            <div class="small">Bienvenido:</div>
            {{ auth()->user()->name }}
        </div>-->
    </nav>
</div>