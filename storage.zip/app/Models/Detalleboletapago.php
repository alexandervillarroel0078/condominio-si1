<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Detalleboletapago extends Model
{
    use HasFactory;

    public function boletapago(){
        return $this->belongsTo(Boletapago::class);
    }
}
