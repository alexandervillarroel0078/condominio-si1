<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Builder;

//use DragonCode\Support\Facades\Http\Builder;

//use Illuminate\Contracts\Database\Query\Builder;
//Builder
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;

class Cliente extends Model
{
    use HasFactory;

    public function telefonos(){
        return $this->hasMany(Telefono::class);
    }

    public function pedidos(){
        return $this->hasMany(Pedido::class);
    }

    protected $fillable = ['nombre', 'ci', 'nit', 'tipo_cliente', 'email', 'direccion'];

    public function scopeFiltrarPorNombre(Builder $query, Request $request){
        return $query->when($request->has('nombre'), function($query) use ($request){
            return $query->where('nombre', 'LIKE', '%'.$request->nombre.'%')
            ->orWhere('email', 'LIKE', '%'.$request->nombre.'%')
            ->orWhere('direccion', 'LIKE', '%'.$request->nombre.'%');
        });
    }

    public function scopeFiltrarPorTipo(Builder $query, Request $request){
        return$query->when($request->has('tipo_cliente'), function($query) use ($request){
            return $query->where('tipo_cliente', 'LIKE', $request->tipo_cliente);
        });        
    }

    public function scopeFiltrarPorEstado(Builder $query, Request $request){
        return$query->when($request->has('estado'), function($query) use ($request){
            return $query->where('estado', 'LIKE', $request->estado);
        });        
    }
}
