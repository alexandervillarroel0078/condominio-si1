<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreUsuarioRequest;
use App\Http\Requests\updateUsuarioRequest;
use App\Models\Empleado;
use App\Models\User;
use Exception;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use PhpParser\Node\Stmt\TryCatch;
use Spatie\Permission\Models\Role;
use App\Traits\BitacoraTrait;

class UsuarioController extends Controller
{
    use BitacoraTrait;
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        
        $roles = Role::all();
        $empleados = Empleado::all();
        return view('users.create', compact('roles', 'empleados'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreUsuarioRequest $request)
    {   
     //  dd($request);
        try {
            $user = new User();
            DB::beginTransaction();
            $user->fill([
                'empleado_id' => $request->empleado_id,
                'name' => $request->name,
                'email' => $request->email,
                'email_verified_at' => null,
                'password' => Hash::make($request->password)
            ]);
            $this->registrarEnBitacora('Usuario creado', $user->id);
           
            //Asignar su rol
            $user->assignRole($request->role);
            $user->save();
          DB::commit();
           
        } catch (Exception $e) {
            DB::rollback();
            $this->registrarEnBitacora('Error al crear usuario creado: ' . $e->getMessage());
        }
        return redirect()->route('users.index')->with('success', 'Usuario registrado con éxito.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(User $user)
    {
        $empleados = Empleado::where('estado', 1)->get();
        $roles = Role::all();
        return view('users.edit', compact('user', 'empleados', 'roles'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(updateUsuarioRequest $request, User $user)
    {
        //$request->password = Hash::make($request->password);
        // a la contraseña en el update hacer hash para el password
        // de momento no se esta haciendo update en el password

        try{
            DB::beginTransaction();

         //   User::where('id', $user->id)->update($request->validated());

            // Registrar acción en la bitácora
            $this->registrarEnBitacora('Usuario actualizado', $user->id);
            $user->update($request->all());

            //$user->roles()->sync($request->roles);
            $user->syncRoles([$request->role]);
            DB::commit();
        }catch(Exception $e) {
            DB::rollBack();
            $this->registrarEnBitacora('Error al actualizar usuario: ' . $e->getMessage());
        }
          
        return redirect()->route('users.index')->with('success', 'El usuario se a actualizado');


    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $user = User::find($id);
        if ($user->activo == 1) {
            User::where('id', $user->id)->update([
                'activo' => 0
            ]);
            $this->registrarEnBitacora('Usuario desactivado: ', $user->id);
            return redirect()->route('users.index')->with('success', 'El usuario ha sido dado de baja');
        }

        return redirect()->route('users.index');
    }
}
