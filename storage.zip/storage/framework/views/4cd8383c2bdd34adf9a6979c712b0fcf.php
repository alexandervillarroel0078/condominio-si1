


<?php $__env->startSection('title', 'Nuevo servicio'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Nuevo servicio</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(route('servicios.index')); ?>">Servicios</a></li>
        <li class="breadcrumb-item active">Crear</li>
    </ol>

    <form action="<?php echo e(route('servicios.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group mb-2">
            <label>Nombre del servicio</label>
            <input type="text" name="nombre" class="form-control" required value="<?php echo e(old('nombre')); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Descripción (opcional)</label>
            <textarea name="descripcion" class="form-control"><?php echo e(old('descripcion')); ?></textarea>
        </div>
        <div class="form-group mb-2">
            <label>Duración (minutos)</label>
            <input type="number" name="duracion_minutos" class="form-control" required min="5" value="<?php echo e(old('duracion_minutos')); ?>">
        </div>
        <div class="form-group mb-2">
            <label>Precio (Bs.)</label>
            <input type="number" name="precio" class="form-control" step="0.01" required value="<?php echo e(old('precio')); ?>">
        </div>
        <div class="form-group mb-3">
            <label>Categoría (opcional)</label>
            <input type="text" name="categoria" class="form-control" value="<?php echo e(old('categoria')); ?>">
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-success btn-sm">Guardar</button>
            <a href="<?php echo e(route('servicios.index')); ?>" class="btn btn-secondary btn-sm">Cancelar</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/servicios/create.blade.php ENDPATH**/ ?>