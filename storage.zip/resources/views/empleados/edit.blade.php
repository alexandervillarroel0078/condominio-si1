@extends('plantilla')

@section('title', 'Editar empleado')

@push('css')
    
@endpush

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">Editar empleado</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item "><a href="{{ route('panel') }}">Inicio</a></li>
        <li class="breadcrumb-item "><a href="{{ route('empleados.index') }}">Empleados</a></li>
        <li class="breadcrumb-item active">Editar empleado</li>
    </ol>
    <div class="from-orange-200">
        <form action="{{ route('empleados.update', ['empleado' => $empleado]) }}" method="POST">
            @csrf
            @method('PATCH')
            <div class="form-group mb-2">
                <label for="tipo_empleado">Tipo empleado</label>
                <select class="form-control" name="tipo_empleado" id="tipo_empleado">
                    <option value="">--Seleccione Tipo Empleado--</option>
                    @foreach ($tipo_empleados as $tipo_empleado)
                        <option value="{{ $tipo_empleado->descripcion }}" {{ $empleado->tipo_empleado==$tipo_empleado->descripcion ? 'selected' : '' }}> {{ $tipo_empleado->descripcion }} </option>
                    @endforeach
                </select>
                @error('tipo_empleado')
                    <small class="text-danger"> {{ '*' . $message }} </small>
                @enderror
            </div>
            <div class="form-group mb-2">
                <label for="nombre">Nombre completo</label>
                <input type="text" class="form-control" name="nombre" id="nombre"
                    placeholder="introduzca nombre completo" value="{{ $empleado->nombre }}">
                @error('nombre')
                    <small class="text-danger"> {{ '*' . $message }} </small>
                @enderror
            </div>
            <div class="form-group mb-2" id="grupoCI">
                <label for="ci">Nro CI</label>
                <input type="number" class="form-control" name="ci" id="ci" placeholder="introduzca CI"
                    value="{{ $empleado->ci }}" width="100">
                @error('ci')
                    <small class="text-danger"> {{ '*' . $message }} </small>
                @enderror
            </div>            
            <div class="form-group mb-2">
                <label for="telefono">Teléfono</label>
                <input type="text" class="form-control" name="telefono" id="telefono"
                    placeholder="Ingrese número de teléfono" value="{{ $empleado->telefono }}">
                @error('telefono')
                    <small class="text-danger"> {{ '*' . $message }} </small>
                @enderror
            </div>
            <div class="form-group mb-2">
                <label for="direccion">Dirección</label>
                <input type="text" class="form-control" name="direccion" id="direccion"
                    placeholder="ingrese una dirección" value="{{ $empleado->direccion }}">
                @error('direccion')
                    <small class="text-danger"> {{ '*' . $message }} </small>
                @enderror
            </div>
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-primary btn-sm"> Actualizar </button>
                <button type="reset" class="btn btn-secondary btn-sm"> Restaurar datos </button>
                <a href="{{ route('empleados.index') }}"><button type="button" class="btn btn-success btn-sm"> <i class="fa-solid fa-arrow-left"></i> Atras </button></a>                    
            </div>
        </form>
    </div>
</div>
@endsection

@push('js')
    
@endpush
