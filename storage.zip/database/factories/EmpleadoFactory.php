<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Empleado>
 */
class EmpleadoFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $fecha = $this->faker->dateTimeBetween();
        return [
            'nombre' => $this->faker->name(),
            'ci' => $this->faker->numberBetween(1111111, 99999999),
            'telefono' => $this->faker->numberBetween(33555555, 79999999),
            'direccion' => $this->faker->address(),
            'tipo_empleado' => $this->faker->randomElement([
                'Estilista',
                'Manicurista',
                'Barbero',
            ]),
            'estado' => 1,
            'fecha_alta' => $fecha,
            'fecha_baja' => null,
            'created_at' => $fecha,
            'updated_at' => $fecha
        ];
    }
}
