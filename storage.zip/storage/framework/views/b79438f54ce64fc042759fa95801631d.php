<?php $__env->startSection('title', 'Solicitudes de servicio'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Solicitudes de servicio</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Solicitudes</li>
    </ol>
    <div class="mb-4 text-end">
        <a href="<?php echo e(route('pedidos.create')); ?>" class="btn btn-primary btn-sm">Nuevo pedido</a>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Lista de servicios solicitados
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Fecha</th>
                        <th>Fecha entrega</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pedidos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pedido): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($pedido->id); ?></td>
                            <td><?php echo e($pedido->cliente->nombre ?? 'N/A'); ?></td>
                            <td><?php echo e($pedido->servicio->nombre ?? 'N/A'); ?></td>
                            <td><?php echo e($pedido->fecha); ?></td>
                            <td><?php echo e($pedido->fecha_entrega); ?></td>
                            <td>
                                <span class="badge bg-<?php echo e($pedido->estado == 1 ? 'success' : 'secondary'); ?>">
                                    <?php echo e($pedido->estado == 1 ? 'Activo' : 'Finalizado'); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No hay solicitudes aún.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/pedidos/index.blade.php ENDPATH**/ ?>