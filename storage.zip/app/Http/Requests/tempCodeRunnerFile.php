<?php
'nombre' => 'required|max:50',
            'ci'=> 'nullable|max:8|unique:clientes,ci',
            'nit'=> 'nullable|max:11|unique:clientes,nit',
            'tipo_cliente'=> 'required',
            'email'=> 'nullable|max:50',
            'direccion'=> 'required|max:100'