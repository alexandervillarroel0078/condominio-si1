


<?php $__env->startSection('title', 'Servicios'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Servicios ofrecidos</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active">Servicios</li>
    </ol>

    <a href="<?php echo e(route('servicios.create')); ?>" class="btn btn-primary btn-sm mb-3">Nuevo servicio</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success small"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <div class="card mb-4">
        <div class="card-header">Listado de servicios</div>
        <div class="card-body">
            <table class="table table-striped table-sm">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Duración (min)</th>
                        <th>Precio</th>
                        <th>Categoría</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($servicio->nombre); ?></td>
                            <td><?php echo e($servicio->duracion_minutos); ?></td>
                            <td>Bs. <?php echo e(number_format($servicio->precio, 2)); ?></td>
                            <td><?php echo e($servicio->categoria ?? 'Sin categoría'); ?></td>
                            <td>
                                <a href="<?php echo e(route('servicios.edit', $servicio->id)); ?>" class="btn btn-sm btn-warning">Editar</a>
                                <form action="<?php echo e(route('servicios.destroy', $servicio->id)); ?>" method="POST" style="display:inline-block;">
                                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm btn-danger" onclick="return confirm('¿Eliminar este servicio?')">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($servicios->isEmpty()): ?>
                        <tr><td colspan="5">No hay servicios registrados.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/servicios/index.blade.php ENDPATH**/ ?>