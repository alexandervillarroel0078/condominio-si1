<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Model>
 */
class ClienteFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'nombre' => $this->faker->name(),
            'ci' => $this->faker->numberBetween(1111111, 99999999),
            'nit' => $this->faker->numberBetween(11111111111, 99999999999),
            'tipo_cliente' => $this->faker->randomElement([
                'PARTICULAR',
                'EMPRESA',
                'VIP',
                'FRECUENTE',
                'NUEVO',
                'RECOMENDADO'
            ]),
            'email' => $this->faker->email(),
            'direccion' => $this->faker->address(),
            'estado' => 1,
            'fecha_alta' => $this->faker->dateTimeBetween(),
            'fecha_baja' => null,
        ];
    }
}
