<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EmpleadosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $empleado = [
            'nombre' => 'Remberto Trujillo',
            'ci' => '6598727',
            'telefono' => '63689645',
            'direccion' => 'Avenida las Américas, nro 378',
            'tipo_empleado' => 'Estilista',
            'estado' => 1,
            'fecha_alta' => now(),
            'fecha_baja' => null,
            'created_at' => now(),
            'updated_at' => now()
        ];
        DB::table('empleados')->insert($empleado);
        \App\Models\Empleado::factory(100)->create();
    }
}
