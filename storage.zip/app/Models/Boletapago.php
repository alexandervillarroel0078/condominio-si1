<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Boletapago extends Model
{
    use HasFactory;

    public function empleado(){
        return $this->belongsTo(Empleado::class);
    }

    public function detalleboletapagos(){
        return $this->hasMany(Detalleboletapago::class);
    }

    public function anticipoempleados(){
        return $this->hasMany(Anticipoempleado::class);
    }
}
