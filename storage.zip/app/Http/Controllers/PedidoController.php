<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\Pedido;
use App\Models\Servicio;
use Illuminate\Http\Request;

class PedidoController extends Controller
{
    /**
     * Mostrar listado de pedidos.
     */
    public function index()
    {
        // Traer pedidos con relaciones cliente y servicio
        $pedidos = Pedido::with(['cliente', 'servicio'])->get();

        return view('pedidos.index', compact('pedidos'));
    }

    /**
     * Mostrar formulario para crear pedido.
     */
    public function create()
    {
        $clientes = Cliente::where('estado', 1)->latest()->get();
        $servicios = Servicio::all();

        return view('pedidos.create', compact('clientes', 'servicios'));
    }

    /**
     * Guardar nuevo pedido en la base de datos.
     */
    public function store(Request $request)
{
    $request->validate([
        'cliente_id' => 'required|exists:clientes,id',
        'servicio_id' => 'required|exists:servicios,id',
        'fecha' => 'required|date',
        'fecha_entrega' => 'required|date',
    ]);

    $servicio = \App\Models\Servicio::findOrFail($request->servicio_id); // buscar el precio

    $pedido = new Pedido();
    $pedido->user_id = auth()->id(); // si tenés auth funcionando
    $pedido->cliente_id = $request->cliente_id;
    $pedido->servicio_id = $request->servicio_id;
    $pedido->fecha = $request->fecha;
    $pedido->fecha_entrega = $request->fecha_entrega;
    $pedido->total = $servicio->precio; // 👈 AQUÍ está lo que faltaba
    $pedido->estado = 1;
    $pedido->save();

    return redirect()->route('pedidos.index')->with('success', 'Servicio solicitado con éxito.');
}


    public function show(string $id)
    {
        //
    }

    public function edit(string $id)
    {
        //
    }

    public function update(Request $request, string $id)
    {
        //
    }

    public function destroy(string $id)
    {
        //
    }
}
