<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pedido extends Model
{
    use HasFactory;

    // Relaciones existentes
    public function notaventas()
    {
        return $this->hasMany(Notaventa::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function anticipoclientes()
    {
        return $this->hasMany(Anticipocliente::class);
    }

    // Relación con Cliente
    public function cliente()
    {
        return $this->belongsTo(Cliente::class);
    }

    // Relación con Servicio
    public function servicio()
    {
        return $this->belongsTo(Servicio::class);
    }
}
