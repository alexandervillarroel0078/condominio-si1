<?php

use App\Http\Controllers\LoginController;
use App\Http\Controllers\clienteController;
use App\Http\Controllers\empleadoController;
use App\Http\Controllers\homeController;
use App\Http\Controllers\logoutController;
use App\Http\Controllers\pedidoController;
use App\Http\Controllers\roleController;
use App\Http\Controllers\userController;
use App\Http\Controllers\usuarioController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ServicioController;


Route::get('/', [homeController::class, 'index'])->name('panel');
Route::get('/panel', [homeController::class, 'index']);
Route::get('clientes/pdfCliente/{id}', [clienteController::class, 'pdfCliente'])->name('clientes.pdfCliente');
Route::get('clientes/informeClientes/', [clienteController::class, 'pdfClientes'])->name('clientes.informeClientes');
Route::post('/clientes/{cliente}/', [clienteController::class, 'storeTelefono'])->name('clientes.addtelefonos');
Route::post('/clientes/{cliente}/{telefono}/', [clienteController::class, 'deleteTelefono'])->name('clientes.deltelefonos');
Route::resource('servicios', ServicioController::class)->middleware('auth');

Route::resources([    
    'users' => usuarioController::class,
    'empleados' => empleadoController::class,
    'clientes' => clienteController::class,
    'pedidos' => pedidoController::class,
    'roles'=>roleController::class
]);

Route::get('/login', [LoginController::class, 'index'])->name('login');
Route::post('/login', [LoginController::class, 'login']);
Route::get('/logout', [logoutController::class, 'logout'])->name('logout');

Route::get('/401', function () {
    return view('pages.401');
});
Route::get('/404', function () {
    return view('pages.404');
});
Route::get('/500', function () {
    return view('pages.500');
});