<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('boletapagos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('usuario_id')->constrained('users')->restrictOnDelete();
            $table->foreignId('empleado_id')->constrained('empleados')->restrictOnDelete();
            $table->dateTime('fecha');
            $table->date('mes');
            $table->tinyInteger('dias_trabajado');
            $table->string('tipo_pago', 45);
            $table->decimal('sueldo', 10, 3);
            $table->decimal('total_ganado', 10, 3);
            $table->decimal('liquido_pagable', 10, 3);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('boletapagos');
    }
};
