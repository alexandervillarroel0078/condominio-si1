@extends('plantilla')

@section('title', 'Solicitudes de servicio')

@section('content')
<div class="container-fluid px-4">
    <h1 class="mt-4">Solicitudes de servicio</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item"><a href="{{ route('panel') }}">Inicio</a></li>
        <li class="breadcrumb-item active">Solicitudes</li>
    </ol>
    <div class="mb-4 text-end">
        <a href="{{ route('pedidos.create') }}" class="btn btn-primary btn-sm">Nuevo pedido</a>
    </div>

    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif

    <div class="card mb-4">
        <div class="card-header">
            <i class="fas fa-table me-1"></i>
            Lista de servicios solicitados
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Fecha</th>
                        <th>Fecha entrega</th>
                        <th>Estado</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($pedidos as $pedido)
                        <tr>
                            <td>{{ $pedido->id }}</td>
                            <td>{{ $pedido->cliente->nombre ?? 'N/A' }}</td>
                            <td>{{ $pedido->servicio->nombre ?? 'N/A' }}</td>
                            <td>{{ $pedido->fecha }}</td>
                            <td>{{ $pedido->fecha_entrega }}</td>
                            <td>
                                <span class="badge bg-{{ $pedido->estado == 1 ? 'success' : 'secondary' }}">
                                    {{ $pedido->estado == 1 ? 'Activo' : 'Finalizado' }}
                                </span>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center">No hay solicitudes aún.</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
