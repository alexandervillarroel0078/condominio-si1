<?php $__env->startSection('title', 'Crear cliente'); ?>

<?php $__env->startPush('css'); ?>
    <style type="text/css">
        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=number] {
            -moz-appearance: textfield;
        }


        input[type=date]::-webkit-inner-spin-button,
        input[type=date]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        input[type=date] {
            -moz-appearance: textfield;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid px-4">
        <h1 class="mt-4">Crear cliente</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item "><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
            <li class="breadcrumb-item "><a href="<?php echo e(route('clientes.index')); ?>">Clientes</a></li>
            <li class="breadcrumb-item active">Crear</li>
        </ol>
        <div class="from-orange-200">
            <form action="<?php echo e(route('clientes.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-sm-6 mb-2">
                        <label for="tipo_cliente">Tipo cliente</label>
                        <select class="form-control" name="tipo_cliente" id="tipo_cliente" onchange="ShowSelected();">
                            <option value="">--Seleccione Tipo Cliente--</option>
                            <?php $__currentLoopData = $tipo_clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo_cliente->descripcion); ?>"
                                    <?php echo e(old('tipo_cliente') == $tipo_cliente->descripcion ? 'selected' : ''); ?>>
                                    <?php echo e($tipo_cliente->descripcion); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['tipo_cliente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e('*' . $message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-sm-6 mb-2" id="grupoCI">
                        <label for="ci">Nro CI</label>
                        <input type="number" class="form-control" name="ci" id="ci" placeholder="introduzca CI"
                            value="<?php echo e(old('ci')); ?>" width="100">
                        <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-sm-6 mb-2" id="grupoNIT">
                        <label for="nit">Nro NIT</label>
                        <input type="number" class="form-control" name="nit" id="nit"
                            placeholder="introduzca NIT" value="<?php echo e(old('nit')); ?>" width="120">
                        <?php $__errorArgs = ['nit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                </div>
                <div class="form-group mb-2">
                    <label for="nombre">Nombre completo</label>
                    <input type="text" class="form-control" name="nombre" id="nombre"
                        placeholder="introduzca nombre completo" value="<?php echo e(old('nombre')); ?>">
                    <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-2">
                    <label for="email">Correo electrónico</label>
                    <input type="email" class="form-control" name="email" id="email"
                        placeholder="nombre@ejemplo.com" value="<?php echo e(old('email')); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-2">
                    <label for="direccion">Dirección</label>
                    <input type="text" class="form-control" name="direccion" id="direccion"
                        placeholder="ingrese una dirección" value="<?php echo e(old('direccion')); ?>">
                    <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group mb-2">
                    <label for="telefono">Teléfono</label>
                    <input type="text" class="form-control" name="telefono" id="telefono"
                        placeholder="ingrese número de telefono" value="<?php echo e(old('telefono')); ?>">
                    <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-12 text-center">
                    <button type="submit" class="btn btn-primary btn-sm"> Guardar </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script>
        function ShowSelected() {
    var seleccion = $("#tipo_cliente option:selected").val();

    if (seleccion === 'PARTICULAR' || seleccion === 'VIP' || seleccion === 'NUEVO' || seleccion === 'FRECUENTE' || seleccion === 'RECOMENDADO') {
        $("#grupoCI").show();
        $("#grupoNIT").hide();
    } else if (seleccion === 'EMPRESA') {
        $("#grupoCI").hide();
        $("#grupoNIT").show();
    }
}

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/clientes/create.blade.php ENDPATH**/ ?>