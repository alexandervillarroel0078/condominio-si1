<?php $__env->startSection('title', 'Clientes'); ?>

<?php $__env->startPush('css'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <?php if(session('success')): ?>
        <script>
            let message = "<?php echo e(session('success')); ?>"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: message
            });
        </script>
    <?php endif; ?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">Clientes</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>"> Inicio </a></li>
            <li class="breadcrumb-item active">Clientes</li>
        </ol>
        <div class="col-sm-12 mt-4" style="text-align:right">
            <a href="<?php echo e(route('clientes.create')); ?>"><button type="button" class="btn btn-primary btn-sm">Nuevo
                    cliente</button></a>
        </div>
        <form action="<?php echo e(route('clientes.index')); ?>" method="GET">
            <h5>Buscar por</h5>
            <div class="row mb-4">
                <div class="col-sm-3">
                    <label for="nombre">Texto</label>
                    <input type="text" class="form-control" name="nombre" id="nombre" placeholder="texto a buscar"
                        value="<?php echo e(request('nombre')); ?>">
                </div>
                <div class="col-sm-3">
                    <label for="estado">Estado cliente</label>
                    <select class="form-control" name="estado" id="estado">
                        <option value="" <?php echo e(is_null($estado) ? 'selected' : ''); ?>>Todos</option>
                        <option value="0" <?php echo e(is_null($estado) ? '' : ($estado == 0 ? 'selected' : '')); ?>>Eliminado
                        </option>
                        <option value="1" <?php echo e($estado == 1 ? 'selected' : ''); ?>>Activos</option>
                    </select>
                </div>
                <div class="col-sm-3">
                    <label for="estado">Tipo cliente</label>
                    <select class="form-control" name="tipo_cliente" id="tipo_cliente">
                        <option value="" selected>Todos</option>
                        <?php $__currentLoopData = $tipo_clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tipo_cliente->descripcion); ?>"
                                <?php echo e(request('tipo_cliente') == $tipo_cliente->descripcion ? 'selected' : ''); ?>>
                                <?php echo e($tipo_cliente->descripcion); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-sm-3 mt-4 pt-1">
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <a href="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Realizar búsqueda">
                            <button type="submit" class="btn btn-primary btn-sm"><i
                                    class="fa-solid fa-magnifying-glass"></i>
                            </button>
                        </a>
                        <form action="<?php echo e(route('clientes.informeClientes')); ?>" method="POST" target="_blank">
                            <?php echo csrf_field(); ?>
                            <button formtarget="_blank" type="submit" formaction="<?php echo e(route('clientes.informeClientes')); ?>" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generar informe"
                                class="btn btn-secondary btn-sm">
                                <i class="fa-solid fa-print"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </form>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Tabla Clientes
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Dirección</th>
                            <th>Tipo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(is_null($clientes)): ?>
                            <tr>
                                <td colspan="5">
                                    No hay resultados para la búsqueda
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($cliente->nombre); ?>

                                    </td>

                                    <td>
                                        <?php echo e($cliente->email); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cliente->direccion); ?>

                                    </td>
                                    <td>
                                        <?php echo e($cliente->tipo_cliente); ?>

                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <form action="<?php echo e(route('clientes.edit', ['cliente' => $cliente])); ?>"
                                                method="GET">
                                                <button data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Editar registro" type="submit" class="btn btn-primary btn-sm"><i
                                                        class="fas fa-edit"></i></button>
                                            </form>
                                            <a data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generar informe"
                                                class="btn btn-info btn-sm"
                                                href="<?php echo e(route('clientes.pdfCliente', ['id' => $cliente->id])); ?>"
                                                target="_blank"><i class="fa-solid fa-print"></i>
                                            </a>
                                            <span class="btn btn-<?php echo e($cliente->estado == 1 ? 'danger' : 'success'); ?> btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#eliminar-restaurar-<?php echo e($cliente->id); ?>">
                                                <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="<?php echo e($cliente->estado == 1 ? 'Eliminar' : 'Restaurar'); ?> registro"
                                                    id="eliminar">
                                                    <i
                                                        class=" <?php echo e($cliente->estado == 1 ? 'fa-solid fa-trash-can' : 'fa-solid fa-refresh'); ?> "></i>
                                                </a>
                                            </span>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Modal eliminar-restaurar -->
                                <div class="modal fade" id="eliminar-restaurar-<?php echo e($cliente->id); ?>"
                                    data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                                    aria-labelledby="confimarModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="confimarModalLabel">
                                                    <?php echo e($cliente->estado == 1 ? 'Eliminar' : 'Restaurar'); ?> cliente</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                ¿ Desea <?php echo e($cliente->estado == 1 ? 'eliminar' : 'restaurar'); ?> al cliente :
                                                <?php echo e($cliente->nombre); ?> ?
                                            </div>
                                            <div class="modal-footer">
                                                <form
                                                    action="<?php echo e(route('clientes.destroy', ['cliente' => $cliente->id])); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <input type="text" name="valor" id="valor" value="0"
                                                        hidden>
                                                    <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                                </form>
                                                <button type="button" class="btn btn-secondary btn-sm"
                                                    data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
    <script>
        $(function() {
            $('[data-bs-toggle="tooltip"]').tooltip();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/clientes/index.blade.php ENDPATH**/ ?>