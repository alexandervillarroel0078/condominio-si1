@extends('plantilla')

@section('title', 'Clientes')

@push('css')
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
@endpush

@section('content')
    @if (session('success'))
        <script>
            let message = "{{ session('success') }}"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: message
            });
        </script>
    @endif

    <div class="container-fluid px-4">
        <h1 class="mt-4">Clientes</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="{{ route('panel') }}"> Inicio </a></li>
            <li class="breadcrumb-item active">Clientes</li>
        </ol>
        <div class="col-sm-12 mt-4" style="text-align:right">
            <a href="{{ route('clientes.create') }}"><button type="button" class="btn btn-primary btn-sm">Nuevo
                    cliente</button></a>
        </div>
        <form action="{{ route('clientes.index') }}" method="GET">
            <h5>Buscar por</h5>
            <div class="row mb-4">
                <div class="col-sm-3">
                    <label for="nombre">Texto</label>
                    <input type="text" class="form-control" name="nombre" id="nombre" placeholder="texto a buscar"
                        value="{{ request('nombre') }}">
                </div>
                <div class="col-sm-3">
                    <label for="estado">Estado cliente</label>
                    <select class="form-control" name="estado" id="estado">
                        <option value="" {{ is_null($estado) ? 'selected' : '' }}>Todos</option>
                        <option value="0" {{ is_null($estado) ? '' : ($estado == 0 ? 'selected' : '') }}>Eliminado
                        </option>
                        <option value="1" {{ $estado == 1 ? 'selected' : '' }}>Activos</option>
                    </select>
                </div>
                <div class="col-sm-3">
                    <label for="estado">Tipo cliente</label>
                    <select class="form-control" name="tipo_cliente" id="tipo_cliente">
                        <option value="" selected>Todos</option>
                        @foreach ($tipo_clientes as $tipo_cliente)
                            <option value="{{ $tipo_cliente->descripcion }}"
                                {{ request('tipo_cliente') == $tipo_cliente->descripcion ? 'selected' : '' }}>
                                {{ $tipo_cliente->descripcion }} </option>
                        @endforeach
                    </select>
                </div>
                <div class="col-sm-3 mt-4 pt-1">
                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                        <a href="" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Realizar búsqueda">
                            <button type="submit" class="btn btn-primary btn-sm"><i
                                    class="fa-solid fa-magnifying-glass"></i>
                            </button>
                        </a>
                        <form action="{{ route('clientes.informeClientes') }}" method="POST" target="_blank">
                            @csrf
                            <button formtarget="_blank" type="submit" formaction="{{ route('clientes.informeClientes') }}" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generar informe"
                                class="btn btn-secondary btn-sm">
                                <i class="fa-solid fa-print"></i>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </form>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Tabla Clientes
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Dirección</th>
                            <th>Tipo</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        @if (is_null($clientes))
                            <tr>
                                <td colspan="5">
                                    No hay resultados para la búsqueda
                                </td>
                            </tr>
                        @else
                            @foreach ($clientes as $cliente)
                                <tr>
                                    <td>
                                        {{ $cliente->nombre }}
                                    </td>

                                    <td>
                                        {{ $cliente->email }}
                                    </td>
                                    <td>
                                        {{ $cliente->direccion }}
                                    </td>
                                    <td>
                                        {{ $cliente->tipo_cliente }}
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                            <form action="{{ route('clientes.edit', ['cliente' => $cliente]) }}"
                                                method="GET">
                                                <button data-bs-toggle="tooltip" data-bs-placement="bottom"
                                                    title="Editar registro" type="submit" class="btn btn-primary btn-sm"><i
                                                        class="fas fa-edit"></i></button>
                                            </form>
                                            <a data-bs-toggle="tooltip" data-bs-placement="bottom" title="Generar informe"
                                                class="btn btn-info btn-sm"
                                                href="{{ route('clientes.pdfCliente', ['id' => $cliente->id]) }}"
                                                target="_blank"><i class="fa-solid fa-print"></i>
                                            </a>
                                            <span class="btn btn-{{ $cliente->estado == 1 ? 'danger' : 'success' }} btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#eliminar-restaurar-{{ $cliente->id }}">
                                                <a data-bs-toggle="tooltip" data-bs-placement="top"
                                                    title="{{ $cliente->estado == 1 ? 'Eliminar' : 'Restaurar' }} registro"
                                                    id="eliminar">
                                                    <i
                                                        class=" {{ $cliente->estado == 1 ? 'fa-solid fa-trash-can' : 'fa-solid fa-refresh' }} "></i>
                                                </a>
                                            </span>
                                        </div>
                                    </td>
                                </tr>

                                <!-- Modal eliminar-restaurar -->
                                <div class="modal fade" id="eliminar-restaurar-{{ $cliente->id }}"
                                    data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
                                    aria-labelledby="confimarModalLabel" aria-hidden="true">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="confimarModalLabel">
                                                    {{ $cliente->estado == 1 ? 'Eliminar' : 'Restaurar' }} cliente</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                ¿ Desea {{ $cliente->estado == 1 ? 'eliminar' : 'restaurar' }} al cliente :
                                                {{ $cliente->nombre }} ?
                                            </div>
                                            <div class="modal-footer">
                                                <form
                                                    action="{{ route('clientes.destroy', ['cliente' => $cliente->id]) }}"
                                                    method="POST">
                                                    @csrf
                                                    @method('delete')
                                                    <input type="text" name="valor" id="valor" value="0"
                                                        hidden>
                                                    <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                                </form>
                                                <button type="button" class="btn btn-secondary btn-sm"
                                                    data-bs-dismiss="modal">Cancelar</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @endforeach
                        @endif

                    </tbody>
                </table>

            </div>
        </div>
    </div>
@endsection

@push('js')
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="{{ asset('js/datatables-simple-demo.js') }}"></script>
    <script>
        $(function() {
            $('[data-bs-toggle="tooltip"]').tooltip();
        });
    </script>
@endpush
