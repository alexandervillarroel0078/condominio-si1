<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreEmpleadoRequest;
use App\Http\Requests\updateEmpleadoRequest;
use App\Models\Clasificadore;
use App\Models\Empleado;
use App\Models\User;
use App\Traits\BitacoraTrait;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class EmpleadoController extends Controller
{
    use BitacoraTrait;

    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        
        //$empleados = Empleado::where('estado', 1)->latest()->get();
        $empleados=Empleado::all();
        return view('empleados.index', compact('empleados'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $tipo_empleados = Clasificadore::where('tipo', 'TIPO_EMPLEADO')->get();
        return view('empleados.create', compact('tipo_empleados'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreEmpleadoRequest $request)
    {
        $empleado = new Empleado();
        try {
            DB::beginTransaction();
            $empleado->fill([
                'nombre' => $request->nombre,
                'ci' => $request->ci,
                'telefono' => $request->telefono,
                'direccion' => $request->direccion,
                'tipo_empleado' => $request->tipo_empleado,
                'fecha_alta' => now()
            ]);
            $empleado->save();
            DB::commit();

            // Registrar acción en la bitácora
            $this->registrarEnBitacora('Empleado registrado', $empleado->id);
        } catch (Exception $e) {
            DB::rollback();
        }
        return redirect()->route('empleados.index')->with('success', 'Empleado registrado con éxito.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Empleado $empleado)
    {
        $tipo_empleados = Clasificadore::where('tipo', 'TIPO_EMPLEADO')->get();
        return view('empleados.edit', compact('empleado', 'tipo_empleados'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(updateEmpleadoRequest $request, Empleado $empleado)
    {
        Empleado::where('id', $empleado->id)->update($request->validated());

        // Registrar acción en la bitácora
        $this->registrarEnBitacora('Empleado actualizado', $empleado->id);

        return redirect()->route('empleados.index')->with('success', 'El empleado se ha actualizado');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $empleado = Empleado::find($id);
        if ($empleado->estado == 1) {
            Empleado::where('id', $empleado->id)->update([
                'estado' => 0
            ]);
            $usuario = User::where('empleado_id', $empleado->id);
            if (!$usuario == null) {
                User::where('empleado_id', $empleado->id)->update([
                    'activo' => 0
                ]);
            }

            // Registrar acción en la bitácora
            $this->registrarEnBitacora('Empleado dado de baja', $empleado->id);

            return redirect()->route('empleados.index')->with('success', 'El empleado ha sido dado de baja');
        }
        return redirect()->route('empleados.index');
    }
}
