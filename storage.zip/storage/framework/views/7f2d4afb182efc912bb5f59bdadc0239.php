<?php $__env->startSection('title', 'Empleados'); ?>

<?php $__env->startPush('css'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('success')): ?>
        <script>
            let message = "<?php echo e(session('success')); ?>"
            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 1500,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: message
            });
        </script>
    <?php endif; ?>

    <div class="container-fluid px-4">
        <h1 class="mt-4">Empleados(personal del salon)</h1>
        <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item"><a href="<?php echo e(route('panel')); ?>"> Inicio </a></li>
            <li class="breadcrumb-item active">Empleados</li>
        </ol>
        <div class="mb-4">
            <a href="<?php echo e(route('empleados.create')); ?>"><button type="button" class="btn btn-primary btn-sm">Nuevo
                    empleado(personal del salon)</button></a>
        </div>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table me-1"></i>
                Tabla Empleados(personal del salon)
            </div>
            <div class="card-body">
                <table id="datatablesSimple" class="table table-striped">
                    <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Ci</th>
                            <th>Teléfono</th>
                            <th>Dirección</th>
                            <th>T. personal </th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e($empleado->nombre); ?>

                                </td>
                                <td>
                                    <?php echo e($empleado->ci); ?>

                                </td>
                                <td>
                                    <?php echo e($empleado->telefono); ?>

                                </td>
                                <td>
                                    <?php echo e($empleado->direccion); ?>

                                </td>
                                <td>
                                    <?php echo e($empleado->tipo_empleado); ?>

                                </td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic mixed styles example">
                                        <form action="<?php echo e(route('empleados.edit', ['empleado' => $empleado])); ?>"
                                            method="GET">
                                            <button type="submit" class="btn btn-primary btn-sm">Editar</button>
                                        </form>
                                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal"
                                            data-bs-target="#confimarModal-<?php echo e($empleado->id); ?>">Eliminar</button>
                                    </div>
                                </td>
                            </tr>

                            <!-- Modal -->
                            <div class="modal fade" id="confimarModal-<?php echo e($empleado->id); ?>" data-bs-backdrop="static"
                                data-bs-keyboard="false" tabindex="-1" aria-labelledby="confimarModalLabel"
                                aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="confimarModalLabel">Eliminar empleado</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            ¿ Desea eliminar al empleado: <?php echo e($empleado->nombre); ?>?
                                        </div>
                                        <div class="modal-footer">
                                            <form action="<?php echo e(route('empleados.destroy', ['empleado' => $empleado->id])); ?>"
                                                method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit" class="btn btn-primary btn-sm">Aceptar</button>
                                            </form>
                                            <button type="button" class="btn btn-secondary btn-sm"
                                                data-bs-dismiss="modal">Cancelar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/simple-datatables@7.1.2/dist/umd/simple-datatables.min.js"
        crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/datatables-simple-demo.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/empleados/index.blade.php ENDPATH**/ ?>