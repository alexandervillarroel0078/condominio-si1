@extends('plantillaPDF')

@section('title', 'Imprimir listado clientes')

@push('css')
    <style>
        .cabecera {
            background: blue;
            color: white;
            font-size: 12px;
            padding: 30px;
        }

        .cuerpo {
            font-size: 11px;
            padding: 4pt;
        }

        label.etiqueta-negrita {
            font-weight: bold;
            margin-bottom: 2pt;
        }

        .margin-boton2ptos {
            margin-bottom: 2pt;
        }
    </style>
@endpush

@section('content')
    <div class="container-fluid px-4">
        <h1 class="mt-1 mb-4">LISTADO CLIENTES</h1>
        <h5 class="mt-1 mb-2">Filtro de búsqueda</h5>
        <div class="form-group mb-2">
            <div class="col-md-4">
                <label class="etiqueta-negrita">Texto : </label>
                <label class="margin-boton2ptos">
                    <?php
                    if (is_null($nombre)) {
                        print 'Sin texto ingresado';
                    } else {
                        $nombre_trim = trim($nombre);
                        print ($nombre_trim == '' ? 'Sin texto ingresado' : $nombre);
                    }
                    ?>
                </label>
            </div>
            <div class="col-md-4">
                <label class="etiqueta-negrita">Estado : </label>
                <label class="margin-boton2ptos">
                    <?php
                    if (is_null($estado)) {
                        print 'Todos';
                    } else {
                        print ($estado == '0' ? 'Baja' : 'Activos');
                    }
                    ?>
                </label>
            </div>
            <div class="col-md-4">
                <label class="etiqueta-negrita">Tipo cliente : </label>
                <label class="margin-boton2ptos">
                    <?php
                    if (is_null($tipo_cliente)) {
                        print 'Todos';
                    } else {
                        print $tipo_cliente;
                    }
                    ?>
                </label>
            </div>
        </div>
        <table class="table">
            <thead class="cabecera">
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Dirección</th>
                    <th>Tipo</th>
                    <th>CI / NIT</th>
                    <th>Estado</th>
                    <th>Fecha alta</th>
                </tr>
            </thead>
            <tbody class="cuerpo">
                @foreach ($clientes as $cliente)
                    <tr>
                        <td>{{ $cliente->nombre }}</td>
                        <td>{{ $cliente->email }}</td>
                        <td>{{ $cliente->direccion }}</td>
                        <td>{{ $cliente->tipo_cliente }}</td>
                        <td>{{ $cliente->tipo_cliente == 'PARTICULAR' ? $cliente->ci : $cliente->nit }}</td>
                        <td>{{ $cliente->estado == 1 ? 'Activo' : 'Baja' }}</td>
                        <td>{{ $cliente->fecha_alta }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <div class="form-group mt-5" style="text-align:right">
            <label class="">Fecha emisión : <?php
            echo date('d-m-Y, H:m:s');
            ?></label>
        </div>
    </div>
@endsection

@push('js')
@endpush
