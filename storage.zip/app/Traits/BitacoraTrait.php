<?php

namespace App\Traits;

use App\Models\Bitacora;
use Illuminate\Support\Facades\Auth;

trait BitacoraTrait
{
    public function registrarEnBitacora($accion, $id_operacion = null)
    {
        Bitacora::create([
            'user_id' => Auth::check() ? Auth::id() : null,
            'accion' => $accion,
            'fecha_hora' => now(),
            'id_operacion' => $id_operacion,
        ]);
    }
}
