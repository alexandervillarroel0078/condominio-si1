<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Almacene extends Model
{
    use HasFactory;
    
    public function notasalidas(){
        return $this->hasMany(Notasalida::class);
    }

    public function notacompras(){
        return $this->hasMany(Notacompra::class);
    }

    public function notaventas(){
        return $this->hasMany(Notaventa::class);
    }
}
