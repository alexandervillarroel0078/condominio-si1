<?php $__env->startSection('title', 'Crear empleado'); ?>

<?php $__env->startPush('css'); ?>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Crear empleado</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item "><a href="<?php echo e(route('panel')); ?>">Inicio</a></li>
        <li class="breadcrumb-item "><a href="<?php echo e(route('empleados.index')); ?>">Empleados</a></li>
        <li class="breadcrumb-item active">Crear</li>
    </ol>
    <div class="from-orange-200">
        <form action="<?php echo e(route('empleados.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group mb-2">
                <label for="tipo_empleado">Tipo empleado</label>
                <select class="form-control" name="tipo_empleado" id="tipo_empleado">
                    <option value="">Seleccione Tipo Empleado</option>
                    <?php $__currentLoopData = $tipo_empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo_empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tipo_empleado->descripcion); ?>" <?php echo e(old('tipo_empleado') == $tipo_empleado->descripcion ? 'selected' : ''); ?>> <?php echo e($tipo_empleado->descripcion); ?> </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['tipo_empleado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mb-2">
                <label for="nombre">Nombre completo</label>
                <input type="text" class="form-control" name="nombre" id="nombre"
                    placeholder="introduzca nombre completo" value="<?php echo e(old('nombre')); ?>">
                <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mb-2" id="grupoCI">
                <label for="ci">Nro CI</label>
                <input type="number" class="form-control" name="ci" id="ci" placeholder="introduzca CI"
                    value="<?php echo e(old('ci')); ?>" width="100">
                <?php $__errorArgs = ['ci'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>   
          
            <div class="form-group mb-2">
                <label for="telefono">Teléfono</label>
                <input type="text" class="form-control" name="telefono" id="telefono"
                    placeholder="Ingrese número de teléfono" value="<?php echo e(old('telefono')); ?>">
                <?php $__errorArgs = ['telefono'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
         <div class="form-group mb-2">
                <label for="direccion">Dirección</label>
                <input type="text" class="form-control" name="direccion" id="direccion"
                    placeholder="ingrese una dirección" value="<?php echo e(old('direccion')); ?>">
                <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger"> <?php echo e('*' . $message); ?> </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div> 
            <div class="col-12 text-center">
                <button type="submit" class="btn btn-primary btn-sm"> Guardar </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ProyectoMarBhelo\adminlte\resources\views/empleados/create.blade.php ENDPATH**/ ?>